
class Result {
    constructor(product) {
        this.product = product;
    };
}

module.exports = Result;